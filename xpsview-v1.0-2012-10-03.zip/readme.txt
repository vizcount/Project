/FULLSCREEN	- start in fullscreen mode
/DEBUG		- write log file to temp directory
/NOPRINT	- disable printing
/NOCOPY		- disable cut and copy
/NOSEARCH	- disable search bar
/NONAVIGATION	- hide up/down buttons
/QUITBTN	- show quit button
/EXEC		- EXE which should be executed for the exec:// and execx:// protocol
/EXECPARAM	- Parameter of the EXE declared with /EXEC. $1 is replaced with the content declared after exec:// 
/SIZE		- size of the input file (only needed if pipe is used as input file)
/TITLE		- sets the text in the title bar