﻿#include "stdafx.h"
#include "CommFunc.h"
#include <shlobj.h>
#include <Windows.h>

TCHAR *GetCurPath(void)
{
	static TCHAR s_szCurPath[MAX_PATH] = {0};

	GetModuleFileName(NULL, s_szCurPath, MAX_PATH);

	TCHAR *p = _tcsrchr(s_szCurPath, '\\');
	*p = 0;

	return s_szCurPath;
}

TCHAR *GetProgPath(void)
{
	static TCHAR s_szProgPath[MAX_PATH] = {0};

	SHGetFolderPath(NULL, CSIDL_PROGRAM_FILES, NULL, 1, s_szProgPath);

	return s_szProgPath;
}

TCHAR *GetInstallPath(void)
{
	static TCHAR s_szCfgPath[MAX_PATH] = {0};

	GetModuleFileName(NULL, s_szCfgPath, MAX_PATH);

	TCHAR *p = _tcsrchr(s_szCfgPath, '\\');
	if (p != NULL)
	{
		*p = 0;
	}

	p = _tcsrchr(s_szCfgPath, '\\');
	if (p != NULL)
	{
		*p = 0;
	}

	return s_szCfgPath;
}

// 多字节转宽字节，长度不足时返回需要的长度
LPWSTR MByteToWChar( LPSTR lpcszStr, LPWSTR lpwszStr, DWORD *dwSize, UINT codePage)
{
	DWORD dwMinSize;

 	dwMinSize = MultiByteToWideChar(codePage,NULL,lpcszStr,-1,NULL,0);
 	if(*dwSize < dwMinSize || lpwszStr == NULL)
 	{
		*dwSize = dwMinSize;
 		return NULL;
 	}
 
 	MultiByteToWideChar(codePage,NULL,lpcszStr,-1,lpwszStr,*dwSize);

	*dwSize = dwMinSize;
	return lpwszStr;
}

LPSTR WCharToMByte(LPCWSTR lpcwszStr, LPSTR lpszStr, DWORD *dwSize, UINT codePage)
{
	DWORD dwMinSize;
	dwMinSize = WideCharToMultiByte(codePage,NULL,lpcwszStr,-1,NULL,0,NULL,FALSE);
	if(*dwSize < dwMinSize)
	{
		*dwSize = dwMinSize;
		return NULL;
	}
	WideCharToMultiByte(codePage,NULL,lpcwszStr,-1,lpszStr,*dwSize,NULL,FALSE);
	*dwSize = dwMinSize;
	return lpszStr;
}

//比较两个BSTR类型的字符串
int CompareBSTR(_bstr_t bstr1, _bstr_t bstr2)
{
	if (bstr1 == bstr2)
		return 0;
	else if (bstr1 > bstr2)
		return 1;
	else
		return -1;
}

//比较两个BSTR类型的字符串（忽略大小写）
int CompareBSTRNoCase(_bstr_t bstr1, _bstr_t bstr2)
{
	CComBSTR comBstr1(bstr1.GetBSTR());
	CComBSTR comBstr2(bstr2.GetBSTR());

	comBstr1.ToLower();
	comBstr2.ToLower();

	if (comBstr1 == comBstr2)
		return 0;
	else if (comBstr1 > comBstr2)
		return 1;
	else
		return -1;

}


LONG GetGlobalIndexNum(void)
{
	static LONG lngBase = 0;

	return InterlockedIncrement(&lngBase);
}

char* CStringToUtf8Char(CString& str, int& chLength)
{
	char* pszMultiByte;
	int iSize = WideCharToMultiByte(CP_UTF8, 0, str, -1, NULL, 0, NULL, NULL);
	pszMultiByte = (char*)malloc((iSize + 1)/**sizeof(char)*/);
	memset(pszMultiByte, 0, iSize + 1);
	WideCharToMultiByte(CP_UTF8, 0, str, -1, pszMultiByte, iSize, NULL, NULL);
	chLength = iSize;
	return pszMultiByte;
}

//URL编码
CString URLEncode(CString sIn)
{

	int ilength = -1;
	char* pUrl = CStringToUtf8Char(sIn, ilength);
	CStringA strSrc(pUrl);

	CStringA sOut;
	const int nLen = strSrc.GetLength() + 1;

	register LPBYTE pOutTmp = NULL;
	LPBYTE pOutBuf = NULL;
	register LPBYTE pInTmp = NULL;
	LPBYTE pInBuf = (LPBYTE)strSrc.GetBuffer(nLen);
	BYTE b = 0;

	//alloc out buffer
	pOutBuf = (LPBYTE)sOut.GetBuffer(nLen * 3 - 2);//new BYTE [nLen  * 3];

	if (pOutBuf)
	{
		pInTmp = pInBuf;
		pOutTmp = pOutBuf;

		// do encoding
		while (*pInTmp)
		{
			if (isalnum(*pInTmp))
				*pOutTmp++ = *pInTmp;
			else
			if (isspace(*pInTmp))
				*pOutTmp++ = '+';
			else
			{
				*pOutTmp++ = '%';
				*pOutTmp++ = ToHex(*pInTmp >> 4);
				*pOutTmp++ = ToHex(*pInTmp % 16);
			}
			pInTmp++;
		}
		*pOutTmp = '\0';
		//sOut=pOutBuf;
		//delete [] pOutBuf;
		sOut.ReleaseBuffer();
	}
	strSrc.ReleaseBuffer();
	if (pUrl != NULL)
	{
		delete pUrl;
		pUrl = NULL;
	}
	return CString(sOut);
}

BYTE ToHex(const BYTE &x)
{
	return x > 9 ? x + 55 : x + 48;
}

char * WideToMulti(const wchar_t *pWide, DWORD dwCode)
{
	char *pChar = NULL;
	int  iWlen = 0;

	if (pWide == NULL
		|| (iWlen = wcslen(pWide)) == 0)
	{
		return pChar;
	}

	int iLen = WideCharToMultiByte(dwCode, 0, pWide, iWlen, NULL, NULL, NULL, NULL);
	if (iLen > 0)
	{
		pChar = new char[iLen + 1];
		if (pChar != NULL)
		{
			memset(pChar, 0, iLen + 1);
			WideCharToMultiByte(dwCode, 0, pWide, iWlen, pChar, iLen, NULL, NULL);
		}
	}

	return pChar;
}

char * WideToMulti2(const wchar_t *pWide, DWORD &iLen, DWORD dwCode)
{
	char *pChar = NULL;
	int  iWlen = 0;

	if (pWide == NULL
		|| (iWlen = wcslen(pWide)) == 0)
	{
		return pChar;
	}

	iLen = WideCharToMultiByte(dwCode, 0, pWide, iWlen, NULL, NULL, NULL, NULL);

	if (iLen > 0)
	{
		pChar = new char[iLen + 1];
		if (pChar != NULL)
		{
			memset(pChar, 0, iLen + 1);
			WideCharToMultiByte(dwCode, 0, pWide, iWlen, pChar, iLen, NULL, NULL);
		}
	}

	return pChar;
}

wchar_t * MultitoWide(const char *pMulti, DWORD dwCode /*= CP_ACP*/)
{
	wchar_t *pWide = NULL;
	int iAlen = 0;

	if (pMulti == NULL
		|| (iAlen = strlen(pMulti)) == 0)
	{
		return pWide;
	}

	int iLen = MultiByteToWideChar(dwCode, 0, pMulti, iAlen, NULL, NULL);
	if (iLen > 0)
	{
		pWide = new wchar_t[iLen + 1];
		if (pWide != NULL)
		{
			memset(pWide, 0, (iLen + 1)*sizeof(wchar_t));
			MultiByteToWideChar(dwCode, 0, pMulti, iAlen, pWide, iLen);
		}

	}

	return pWide;
}

//URLDecode
CString Utf8ToStringT(LPSTR str)
{
	CString strResult;
	_ASSERT(str);
	USES_CONVERSION;
	WCHAR *buf;
	int length = MultiByteToWideChar(CP_UTF8, 0, str, -1, NULL, 0);
	buf = new WCHAR[length + 1];
	ZeroMemory(buf, (length + 1) * sizeof(WCHAR));
	MultiByteToWideChar(CP_UTF8, 0, str, -1, buf, length);

	if (str != NULL)
	{
		delete str;
		str = NULL;
	}
	strResult = (CString(W2T(buf)));
	if (buf != NULL)
	{
		delete[]buf;
		buf = NULL;
	}
	return strResult;
}

CString UrlDecode(LPCTSTR url)
{
	_ASSERT(url);
	USES_CONVERSION;
	LPSTR _url = T2A(const_cast<LPTSTR>(url));

	int i = 0;
	int length = (int)strlen(_url);
	CHAR *buf = new CHAR[length + 1];
	ZeroMemory(buf, length + 1);
	LPSTR p = buf;
	while (i < length)
	{
		if (i <= length - 3 && _url[i] == '%' && IsHexNum(_url[i + 1]) && IsHexNum(_url[i + 2]))
		{
			sscanf(_url + i + 1, "%2x", p++);

			i += 3;
		}
		else
		{
			*(p++) = _url[i++];
		}
	}

	return Utf8ToStringT(buf);
}

//替换网页特殊字符
void ReplaceHtmlChar(CString &strData)
{
	static TCHAR tSpecialChar[][2] = { _T("\t"), _T(" "), _T("+"), _T("/"), _T("?"), _T("%"), _T("#"), _T("&"), _T("="), _T("."), _T("\\"), _T(":"), _T("*"), _T("\""), _T("<"), _T(">"), _T("|") };
	for (int i = 0; i < sizeof(tSpecialChar)/sizeof(tSpecialChar[0]); i++)
	{
		strData.Replace(tSpecialChar[i], _T(""));
	}
}
CStringA CStrW2CStrA(const CStringW &cstrSrcW)
{
	int len = WideCharToMultiByte(CP_ACP, 0, LPCWSTR(cstrSrcW), -1, NULL, 0, NULL, NULL);
	char *str = new char[len];
	memset(str, 0, len);
	WideCharToMultiByte(CP_ACP, 0, LPCWSTR(cstrSrcW), -1, str, len, NULL, NULL);
	CStringA cstrDestA = str;
	delete[] str;

	return cstrDestA;
}
CStringW CStrA2CStrW(const CStringA &cstrSrcA)
{
	int len = MultiByteToWideChar(CP_ACP, 0, LPCSTR(cstrSrcA), -1, NULL, 0);
	wchar_t *wstr = new wchar_t[len];
	memset(wstr, 0, len * sizeof(wchar_t));
	MultiByteToWideChar(CP_ACP, 0, LPCSTR(cstrSrcA), -1, wstr, len);
	CStringW cstrDestW = wstr;
	delete[] wstr;

	return cstrDestW;
}
bool SplitCString(const CString & input, const CString & delimiter, std::vector<CString >& results, bool includeEmpties)
{
	int iPos = 0;
	int newPos = -1;
	int sizeS2 = (int)delimiter.GetLength();
	int isize = (int)input.GetLength();

	int offset = 0;
	CString  s;

	if (
		(isize == 0)
		||
		(sizeS2 == 0)
		)
	{
		return 0;
	}

	std::vector<int> positions;

	newPos = input.Find(delimiter, 0);

	if (newPos < 0)
	{
		if (!input.IsEmpty())
		{
			results.push_back(input);
		}
		return 0;
	}

	int numFound = 0;

	while (newPos >= iPos)
	{
		numFound++;
		positions.push_back(newPos);
		iPos = newPos;
		if (iPos + sizeS2 < isize)
		{
			newPos = input.Find(delimiter, iPos + sizeS2);
		}
		else
		{
			newPos = -1;
		}
	}

	if (numFound == 0)
	{
		return 0;
	}

	for (int i = 0; i <= (int)positions.size(); ++i)
	{
		s.Empty();
		if (i == 0)
		{
			s = input.Mid(i, positions[i]);
		}
		else
		{
			offset = positions[i - 1] + sizeS2;

			if (offset < isize)
			{
				if (i == positions.size())
				{
					s = input.Mid(offset);
				}
				else if (i > 0)
				{
					s = input.Mid(positions[i - 1] + sizeS2, positions[i] - positions[i - 1] - sizeS2);
				}
			}
		}

		if (/*includeEmpties || */(s.GetLength() > 0))
		{
			results.push_back(s);
		}
	}
	return true;
}